/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.ArrayList;
import java.util.List;
import dao.DaoUsuario;
import model.Usuario;
/**
 *
 * @author afranio
 */
public class ControllerUsuario {
    private DaoUsuario dao;
    private List<Usuario> usuarios;
    private int indice;

    public ControllerUsuario() {
        this.dao = new DaoUsuario();
        this.usuarios = new ArrayList<Usuario>();
        this.indice = 0;

        carregarUsuarios();
    }

    // =========================================================
    // CRUD
    // =========================================================
    public boolean inserirUsuario(Usuario usuario) {

        if (!usuarioValido(usuario)) {
            return false;
        }

        dao.salvarUsuario(usuario);

        carregarUsuarios();

        ultimo();

        return true;
    }

    public boolean alterarUsuario(Usuario usuario) {

        if (!usuarioValido(usuario)) {
            return false;
        }

        if (usuario.getId() <= 0) {
            return false;
        }

        dao.alterarUsuario(usuario);

        carregarUsuarios();

        return true;
    }

    public Usuario deletarUsuario(int id) {
        if (id <= 0) {
            return null;
        }
        Usuario usuario = getUsuarioPorId(id);
        if (usuario == null) {
            return null;
        }
        // Guarda a posição do usuario que será excluído
        int indiceExcluido = indice;
        dao.excluirUsuario(id);
        carregarUsuarios();
        // Não existem mais usuarios
        if (usuarios.isEmpty()) {
            indice = 0;
            return null;
        }
        /*
     * Se o usuario excluído não era o último,
     * o mesmo índice agora aponta para o próximo usuario.
         */
        if (indiceExcluido < usuarios.size()) {
            indice = indiceExcluido;
        } else {
            /*
         * O usuario excluído era o último.
         * Então voltamos para o anterior.
             */
            indice = usuarios.size() - 1;
        }

        return usuarios.get(indice);
    }
    // =========================================================
    // CONSULTA
    // =========================================================

    public List<Usuario> getUsuarios() {

        carregarUsuarios();

        return usuarios;
    }

    public Usuario getUsuarioPorId(int id) {

        for (Usuario usuario : usuarios) {

            if (usuario.getId() == id) {
                return usuario;
            }
        }

        return null;
    }
    public boolean validarLogin(String email, String senha)
    {
        return dao.verificarLogin(email, senha);
    }
    
    
    
  

    // =========================================================
    // NAVEGAÇÃO
    // =========================================================
    public Usuario primeiro() {

        if (usuarios.isEmpty()) {
            return null;
        }

        indice = 0;

        return usuarios.get(indice);
    }

    public Usuario anterior() {

        if (usuarios.isEmpty()) {
            return null;
        }

        if (indice > 0) {
            indice--;
        }

        return usuarios.get(indice);
    }

    public Usuario proximo() {

        if (usuarios.isEmpty()) {
            return null;
        }

        if (indice < usuarios.size() - 1) {
            indice++;
        }

        return usuarios.get(indice);
    }

    public Usuario ultimo() {

        if (usuarios.isEmpty()) {
            return null;
        }

        indice = usuarios.size() - 1;

        return usuarios.get(indice);
    }

    // =========================================================
    // CONTROLE DOS BOTÕES DE NAVEGAÇÃO
    // =========================================================
    public boolean temAnterior() {

        return !usuarios.isEmpty() && indice > 0;
    }

    public boolean temProximo() {

        return !usuarios.isEmpty() && indice < usuarios.size() - 1;
    }

    public boolean temUsuarios() {

        return !usuarios.isEmpty();
    }

    // =========================================================
    // MÉTODOS AUXILIARES
    // =========================================================
    private void carregarUsuarios() {

        usuarios = dao.getUsuarios();

        if (usuarios == null) {
            usuarios = new ArrayList<>();
        }

        if (usuarios.isEmpty()) {
            indice = 0;
        } else if (indice >= usuarios.size()) {
            indice = usuarios.size() - 1;
        }
    }

    private boolean usuarioValido(Usuario usuario) {

        if (usuario == null) {
            return false;
        }

       
        if (usuario.getNome() == null || usuario.getEmail().trim().isEmpty()) { //senha e perfil
            return false;
        }

        

        return true;
    }

    // =========================================================
    // INFORMAÇÕES DA NAVEGAÇÃO
    // =========================================================
    public int getIndice() {

        return indice;
    }

    public int getQuantidadeUsuarios() {

        return usuarios.size();
    }
}